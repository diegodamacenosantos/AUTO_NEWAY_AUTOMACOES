const RAD = Math.PI / 180;

function normalizar(graus) {
    return ((graus % 360) + 360) % 360;
}

function horaSol(data, lat, lon, nascer) {
    const inicio = Date.UTC(data.getFullYear(), 0, 0);
    const hoje = Date.UTC(data.getFullYear(), data.getMonth(), data.getDate());
    const dia = Math.floor((hoje - inicio) / 86400000);
    const lonHora = lon / 15;
    const t = dia + ((nascer ? 6 : 18) - lonHora) / 24;
    const media = 0.9856 * t - 3.289;
    const verdadeira = normalizar(media + 1.916 * Math.sin(media * RAD) + 0.02 * Math.sin(2 * media * RAD) + 282.634);
    let ascensao = normalizar(Math.atan(0.91764 * Math.tan(verdadeira * RAD)) / RAD);
    ascensao += Math.floor(verdadeira / 90) * 90 - Math.floor(ascensao / 90) * 90;
    ascensao /= 15;
    const senoDec = 0.39782 * Math.sin(verdadeira * RAD);
    const cosDec = Math.cos(Math.asin(senoDec));
    const cosH = (Math.cos(90.833 * RAD) - senoDec * Math.sin(lat * RAD)) / (cosDec * Math.cos(lat * RAD));
    if (cosH > 1 || cosH < -1) return null;
    const angulo = nascer ? 360 - Math.acos(cosH) / RAD : Math.acos(cosH) / RAD;
    const local = angulo / 15 + ascensao - 0.06571 * t - 6.622;
    const ut = (((local - lonHora) % 24) + 24) % 24;
    let instante = hoje + ut * 3600000;
    const meioDia = new Date(data.getFullYear(), data.getMonth(), data.getDate(), 12).getTime();
    while (instante - meioDia > 43200000) instante -= 86400000;
    while (meioDia - instante > 43200000) instante += 86400000;
    return instante;
}

function interpretar(texto) {
    const t = String(texto === undefined || texto === null ? '' : texto).trim().toLowerCase();
    let m = t.match(/^(\d{1,2}):(\d{2})$/);
    if (m) {
        const h = Number(m[1]);
        const min = Number(m[2]);
        if (h > 23 || min > 59) return null;
        return { tipo: 'fixo', minutos: h * 60 + min };
    }
    m = t.match(/^(nascer|por)([+-]\d+)?$/);
    if (m) return { tipo: m[1], deslocamento: m[2] ? Number(m[2]) : 0 };
    return null;
}

function minutosDe(espec, data, lat, lon) {
    if (espec.tipo === 'fixo') return espec.minutos;
    if (typeof lat !== 'number' || typeof lon !== 'number' || Number.isNaN(lat) || Number.isNaN(lon)) return null;
    const instante = horaSol(data, lat, lon, espec.tipo === 'nascer');
    if (instante === null) return null;
    const meiaNoite = new Date(data.getFullYear(), data.getMonth(), data.getDate()).getTime();
    return (instante - meiaNoite) / 60000 + espec.deslocamento;
}

function compilar(regra, contexto) {
    const de = interpretar(regra.de);
    const ate = interpretar(regra.ate);
    const dias = Array.isArray(regra.dias) && regra.dias.length ? regra.dias.map(Number) : [0, 1, 2, 3, 4, 5, 6];
    const lat = contexto && contexto.lat !== undefined && contexto.lat !== '' ? Number(contexto.lat) : null;
    const lon = contexto && contexto.lon !== undefined && contexto.lon !== '' ? Number(contexto.lon) : null;
    const usaSol = (de && de.tipo !== 'fixo') || (ate && ate.tipo !== 'fixo');
    return { de, ate, dias, lat, lon, usaSol, valida: !!(de && ate) };
}

function dentro(hora, agora) {
    if (!hora.valida) return false;
    const a = minutosDe(hora.de, agora, hora.lat, hora.lon);
    const b = minutosDe(hora.ate, agora, hora.lat, hora.lon);
    if (a === null || b === null) return false;
    const m = agora.getHours() * 60 + agora.getMinutes() + agora.getSeconds() / 60;
    const cruza = a > b;
    const ok = cruza ? m >= a || m < b : m >= a && m < b;
    if (!ok) return false;
    const dia = cruza && m < b ? (agora.getDay() + 6) % 7 : agora.getDay();
    return hora.dias.indexOf(dia) !== -1;
}

module.exports = { compilar, dentro, interpretar, horaSol };
