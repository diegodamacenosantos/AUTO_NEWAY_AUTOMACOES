const util = require('util');
const { barramento, ler, interpretar, avaliar, compilarRegras, resolver } = require('./comum');

const REGRAS_PADRAO = [{ t: 'else', alvo: '*', chave: '', espera: '', a: 'orig' }];

module.exports = function (RED) {
    function EstadoSensor(config) {
        RED.nodes.createNode(this, config);
        const node = this;
        const global = node.context().global;

        const campos = (Array.isArray(config.campos) ? config.campos : [])
            .map((c, i) => {
                const nome = String(c.global || '').trim();
                return {
                    campo: String(c.campo || '').trim(),
                    propriedade: String(c.propriedade || '').trim(),
                    tipo: c.tipo === 'flow' || c.tipo === 'global' ? c.tipo : 'msg',
                    global: nome,
                    numero: i + 1,
                    key: nome || String(c.id || '').trim() || '#' + (i + 1)
                };
            });
        const comGlobal = campos.filter((c) => c.global);

        const verdadeiro = (v) => v === true || v === 'true';
        const usaMqtt = config.mqtt === undefined ? !!config.broker : verdadeiro(config.mqtt);
        const usaMsg = config.msg === undefined ? true : verdadeiro(config.msg);

        if (!campos.length) {
            node.status({ fill: 'red', shape: 'ring', text: 'sem entradas' });
            return;
        }

        const lista = Array.isArray(config.rules) && config.rules.length ? config.rules : REGRAS_PADRAO;
        const local = { lat: config.latitude, lon: config.longitude };
        const regras = compilarRegras(lista, (m) => node.warn(m), local);
        const esperas = lista.map((r) => (Number(r.espera) > 0 ? Number(r.espera) : 0));
        const listaConv = Array.isArray(config.conversoes) ? config.conversoes : [];
        const regrasConv = compilarRegras(listaConv, (m) => node.warn(m), local);
        const destinos = lista.map((r) => {
            const prop = String(r.propsaida || '').trim();
            if (prop) return { tipo: r.tiposaida === 'flow' || r.tiposaida === 'global' ? r.tiposaida : 'msg', prop };
            const chave = String(r.chave || '').trim();
            return chave ? { tipo: 'chave', prop: chave } : { tipo: 'msg', prop: 'payload' };
        });
        const pendentes = new Map();
        const ultimoEnviado = new Map();
        let publicador = null;

        function marcaDe(i, c) {
            const d = destinos[i];
            if (d.tipo === 'msg' && d.prop === 'payload') return c.key;
            return d.tipo === 'chave' ? d.prop : d.tipo + '.' + d.prop;
        }

        function texto(valor) {
            return typeof valor === 'object' && valor !== null ? JSON.stringify(valor) : String(valor);
        }

        let exibido = null;
        let ciclos = 0;

        function resumo() {
            const partes = comGlobal.map((c) => {
                const v = global.get(c.global);
                return v === undefined ? null : comGlobal.length > 1 ? c.global + '=' + texto(v) : texto(v);
            });
            return partes.filter((p) => p !== null).join(' | ');
        }

        function mostrar() {
            exibido = resumo();
            if (!exibido && !pendentes.size) {
                node.status({});
                return;
            }
            node.status({
                fill: pendentes.size ? 'yellow' : campos.length === 1 && comGlobal.length === 1 && global.get(campos[0].global) === 'ON' ? 'green' : 'grey',
                shape: pendentes.size ? 'ring' : 'dot',
                text: exibido || '...'
            });
        }

        const vigia = setInterval(() => {
            ciclos++;
            if (resumo() !== exibido || ciclos % 10 === 0) mostrar();
        }, 2000);

        function converter(c, valor) {
            let tem = false;
            for (let i = 0; i < listaConv.length; i++) {
                const alvo = listaConv[i].alvo || '*';
                if (alvo !== '*' && alvo !== c.key) continue;
                tem = true;
                if (regrasConv[i].t === 'else' || avaliar(regrasConv[i], valor)) {
                    return { ok: true, valor: resolver(listaConv[i], valor, c.global ? global.get(c.global) : undefined) };
                }
            }
            return tem ? { ok: false } : { ok: true, valor };
        }

        function carga(regra, valor) {
            switch (regra.a) {
                case 'str':
                    return String(regra.e === undefined ? '' : regra.e);
                case 'num':
                    return Number(regra.e);
                case 'bool':
                    return String(regra.e === undefined ? '' : regra.e).trim().toLowerCase() === 'true';
                case 'json':
                    try {
                        return JSON.parse(regra.e);
                    } catch (e) {
                        return undefined;
                    }
                case 'toggle':
                    return global.get(String(regra.e === undefined ? '' : regra.e).trim()) === 'ON' ? 'OFF' : 'ON';
                default:
                    return valor;
            }
        }

        function montarMensagem(i, c, valor, base) {
            const d = destinos[i];
            const enviado = carga(lista[i], valor);
            if (enviado === undefined) return null;
            const marca = marcaDe(i, c);
            if (c.global) {
                if (util.isDeepStrictEqual(ultimoEnviado.get(marca), enviado)) return null;
                ultimoEnviado.set(marca, enviado);
            }
            const msg = RED.util.cloneMessage(base);
            msg.topic = d.tipo === 'chave' ? d.prop : c.global || 'entrada ' + c.numero;
            if (d.tipo === 'chave') {
                msg.payload = { [d.prop]: enviado };
            } else if (d.tipo === 'msg') {
                RED.util.setMessageProperty(msg, d.prop, enviado, true);
            } else {
                node.context()[d.tipo].set(d.prop, enviado);
                msg.payload = enviado;
            }
            return msg;
        }

        function publicar(msg) {
            if (!publicador) return;
            const topico = String(config.pubTopico || '').trim();
            if (!topico) {
                node.status({ fill: 'yellow', shape: 'ring', text: 'sem tópico de saída' });
                return;
            }
            const p = msg.payload;
            publicador.publish(
                {
                    topic: topico,
                    payload: typeof p === 'string' ? p : typeof p === 'object' && p !== null ? JSON.stringify(p) : String(p),
                    qos: Number(config.pubQos) || 0,
                    retain: verdadeiro(config.pubRetain)
                },
                (erro) => {
                    if (erro) node.error(erro, msg);
                }
            );
        }

        function enviarLote(itens) {
            if (!itens.length) return;
            itens.forEach((item) => publicar(item.msg));
            const saidas = new Array(regras.length).fill(null);
            itens.forEach((item) => {
                saidas[item.i] = (saidas[item.i] || []).concat([item.msg]);
            });
            node.send(saidas.map((s) => (s && s.length === 1 ? s[0] : s)));
        }

        function guardar(c, valor) {
            if (!c.global) return;
            if (util.isDeepStrictEqual(global.get(c.global), valor)) return;
            global.set(c.global, valor);
            barramento.emit(c.global, valor);
        }

        function esperar(i, c, valor, base) {
            const chaveTimer = i + '|' + c.key;
            const existente = pendentes.get(chaveTimer);
            if (existente) {
                existente.valor = valor;
                return;
            }
            const timer = setTimeout(() => {
                const pendente = pendentes.get(chaveTimer);
                pendentes.delete(chaveTimer);
                const msg = montarMensagem(i, c, pendente.valor, base);
                if (msg) enviarLote([{ i, msg }]);
                mostrar();
            }, esperas[i] * 1000);
            pendentes.set(chaveTimer, { timer, valor });
        }

        function cancelar(i, c) {
            const chaveTimer = i + '|' + c.key;
            const existente = pendentes.get(chaveTimer);
            if (!existente) return;
            clearTimeout(existente.timer);
            pendentes.delete(chaveTimer);
        }

        function avaliarRegras(c, valor, base, lote) {
            let achou = false;
            for (let i = 0; i < regras.length; i++) {
                const alvo = lista[i].alvo || '*';
                if (alvo !== '*' && alvo !== c.key) continue;
                const ok = regras[i].t === 'else' ? !achou : avaliar(regras[i], valor);
                if (ok) achou = true;
                if (esperas[i] > 0) {
                    if (ok) esperar(i, c, valor, base);
                    else cancelar(i, c);
                } else if (ok) {
                    const msg = montarMensagem(i, c, valor, base);
                    if (msg) lote.push({ i, msg });
                }
            }
        }

        function lerEntrada(c, msg, dados) {
            if (!c.propriedade) return ler(dados, c.campo);
            try {
                if (c.tipo === 'flow') return node.context().flow.get(c.propriedade);
                if (c.tipo === 'global') return global.get(c.propriedade);
                return RED.util.getMessageProperty(Object.assign({}, msg, { payload: dados }), c.propriedade);
            } catch (e) {
                return undefined;
            }
        }

        function tratar(msg, send, done) {
            const base = Object.assign({}, msg);
            delete base.payload;
            const dados = interpretar(msg.payload);
            const lote = [];
            campos.forEach((c) => {
                const valor = lerEntrada(c, msg, dados);
                if (valor === undefined || valor === null) return;
                const convertido = converter(c, valor);
                if (!convertido.ok) return;
                guardar(c, convertido.valor);
                avaliarRegras(c, convertido.valor, base, lote);
            });
            mostrar();
            enviarLote(lote);
            done();
        }

        function semear() {
            comGlobal.forEach((c) => {
                const anterior = global.get(c.global);
                if (anterior === undefined || anterior === null) return;
                let achou = false;
                for (let i = 0; i < regras.length; i++) {
                    const alvo = lista[i].alvo || '*';
                    if (alvo !== '*' && alvo !== c.key) continue;
                    const ok = regras[i].t === 'else' ? !achou : avaliar(regras[i], anterior);
                    if (!ok) continue;
                    achou = true;
                    ultimoEnviado.set(marcaDe(i, c), carga(lista[i], anterior));
                }
            });
        }

        if (verdadeiro(config.pubMqtt)) {
            publicador = config.pubBroker ? RED.nodes.getNode(config.pubBroker) : null;
            if (!publicador) {
                node.status({ fill: 'red', shape: 'ring', text: 'broker de saída não encontrado' });
            } else {
                publicador.register(node);
                node.on('close', (removido, pronto) => {
                    publicador.deregister(node, pronto, removido);
                });
            }
        }

        semear();
        mostrar();
        if (usaMsg) node.on('input', tratar);

        node.on('close', () => {
            clearInterval(vigia);
            pendentes.forEach((p) => clearTimeout(p.timer));
            pendentes.clear();
        });

        if (usaMqtt) {
            const conexao = config.broker ? RED.nodes.getNode(config.broker) : null;
            const topico = String(config.topico || '').trim();
            if (!conexao) {
                node.status({ fill: 'red', shape: 'ring', text: 'broker não encontrado' });
                return;
            }
            if (!topico) {
                node.status({ fill: 'red', shape: 'ring', text: 'sem tópico' });
                return;
            }
            conexao.register(node);
            conexao.subscribe(
                topico,
                { qos: Number(config.qos) || 0 },
                (recebido, payload) => {
                    tratar({ topic: recebido, payload, _msgid: RED.util.generateId() }, () => {}, () => {});
                },
                node.id
            );
            node.on('close', (removido, pronto) => {
                conexao.unsubscribe(topico, node.id, removido);
                conexao.deregister(node, pronto, removido);
            });
        }
    }
    RED.nodes.registerType('estado-sensor', EstadoSensor);
};
