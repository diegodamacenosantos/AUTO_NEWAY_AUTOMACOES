const { execFile } = require('child_process');
const net = require('net');

const LIMITE_SEGUNDOS = 2;

function enderecoValido(endereco) {
    const texto = String(endereco || '');
    return texto.length <= 253 && /^[A-Za-z0-9][A-Za-z0-9._:-]*$/.test(texto);
}

function interpretarSaida(erro, saida) {
    const texto = String(saida || '');
    if (erro && erro.code === 'ENOENT') return { falha: 'ping não existe neste sistema' };
    if (/not permitted|permission denied/i.test(texto)) return { falha: 'ping sem permissão' };
    const achado = texto.match(/time[=<]\s*([\d.]+)\s*ms/);
    if (erro || !achado) return { ms: 0 };
    return { ms: Math.max(1, Math.round(Number(achado[1]))) };
}

function lerPorta(porta) {
    const texto = String(porta === undefined || porta === null ? '' : porta).trim();
    if (!texto) return 0;
    const numero = Number(texto);
    return /^\d+$/.test(texto) && numero >= 1 && numero <= 65535 ? numero : null;
}

function medirPorta(endereco, porta, pronto) {
    const inicio = process.hrtime.bigint();
    const conexao = net.connect({ host: endereco, port: porta });
    let acabou = false;
    const terminar = (resultado) => {
        if (acabou) return;
        acabou = true;
        clearTimeout(limite);
        conexao.destroy();
        pronto(resultado);
    };
    const limite = setTimeout(() => terminar({ ms: 0 }), LIMITE_SEGUNDOS * 1000);
    conexao.on('connect', () => terminar({ ms: Math.max(1, Math.round(Number(process.hrtime.bigint() - inicio) / 1e6)) }));
    conexao.on('error', () => terminar({ ms: 0 }));
    return {
        kill() {
            acabou = true;
            clearTimeout(limite);
            conexao.destroy();
        }
    };
}

function medir(endereco, pronto, porta) {
    if (porta) return medirPorta(endereco, porta, pronto);
    return execFile('ping', ['-c', '1', '-W', String(LIMITE_SEGUNDOS), endereco], { timeout: (LIMITE_SEGUNDOS + 2) * 1000 }, (erro, stdout, stderr) => {
        pronto(interpretarSaida(erro, String(stdout) + String(stderr)));
    });
}

module.exports = { enderecoValido, interpretarSaida, lerPorta, medir };
