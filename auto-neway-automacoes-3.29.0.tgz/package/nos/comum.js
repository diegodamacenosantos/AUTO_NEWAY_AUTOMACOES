const EventEmitter = require('events');
const relogio = require('./hora');

const barramento = new EventEmitter();
barramento.setMaxListeners(0);

const LIGA = ['on', 'true', '1', 'ligado', 'ligar'];
const DESLIGA = ['off', 'false', '0', 'desligado', 'desligar'];

function normalizar(bruto) {
    if (Buffer.isBuffer(bruto)) bruto = bruto.toString();
    if (bruto === true || bruto === 1) return 'ON';
    if (bruto === false || bruto === 0) return 'OFF';
    if (typeof bruto !== 'string') return null;
    const texto = bruto.trim().toLowerCase();
    if (LIGA.includes(texto)) return 'ON';
    if (DESLIGA.includes(texto)) return 'OFF';
    return null;
}

function ler(objeto, caminho) {
    if (!caminho) return objeto;
    let atual = objeto;
    for (const parte of caminho.split('.')) {
        if (atual === null || typeof atual !== 'object') return undefined;
        atual = atual[parte];
    }
    return atual;
}

function montar(caminho, valor) {
    const partes = caminho.split('.');
    const raiz = {};
    let atual = raiz;
    partes.forEach((parte, i) => {
        if (i === partes.length - 1) {
            atual[parte] = valor;
        } else {
            atual[parte] = {};
            atual = atual[parte];
        }
    });
    return raiz;
}

function interpretar(payload) {
    if (Buffer.isBuffer(payload)) payload = payload.toString();
    if (typeof payload === 'string') {
        try {
            return JSON.parse(payload);
        } catch (e) {
            return payload;
        }
    }
    return payload;
}

const REGRAS_PADRAO = [
    { t: 'eq', v: 'ON', vt: 'str' },
    { t: 'eq', v: 'OFF', vt: 'str' }
];

function converter(valor, tipo) {
    if (valor === undefined) return undefined;
    return tipo === 'num' ? Number(valor) : String(valor);
}

function tamanho(valor) {
    if (typeof valor === 'string' || Array.isArray(valor)) return valor.length;
    if (valor !== null && typeof valor === 'object') return Object.keys(valor).length;
    return null;
}

function avaliar(regra, valor) {
    switch (regra.t) {
        case 'eq':
            return valor == regra.v;
        case 'neq':
            return valor != regra.v;
        case 'lt':
            return Number(valor) < Number(regra.v);
        case 'lte':
            return Number(valor) <= Number(regra.v);
        case 'gt':
            return Number(valor) > Number(regra.v);
        case 'gte':
            return Number(valor) >= Number(regra.v);
        case 'btwn': {
            const minimo = Math.min(Number(regra.v), Number(regra.v2));
            const maximo = Math.max(Number(regra.v), Number(regra.v2));
            const numero = Number(valor);
            return numero >= minimo && numero <= maximo;
        }
        case 'cont':
            return String(valor).indexOf(String(regra.v)) !== -1;
        case 'regex':
            return regra.re !== null && regra.re.test(String(valor));
        case 'hora':
            return regra.hora !== null && relogio.dentro(regra.hora, new Date());
        case 'ignorar':
            return true;
        case 'true':
            return valor === true;
        case 'false':
            return valor === false;
        case 'null':
            return valor === null;
        case 'nnull':
            return valor !== null;
        case 'empty':
            return tamanho(valor) === 0;
        case 'nempty':
            return tamanho(valor) > 0;
        default:
            return false;
    }
}

function compilarRegras(lista, aviso, contexto) {
    return lista.map((r) => {
        const regra = {
            t: r.t,
            v: converter(r.v, r.vt),
            v2: converter(r.v2, r.v2t),
            re: null,
            hora: null
        };
        if (r.t === 'hora') {
            regra.hora = relogio.compilar(r, contexto);
            if (!regra.hora.valida) aviso('horário inválido: ' + r.de + ' ate ' + r.ate);
        }
        if (r.t === 'regex') {
            try {
                regra.re = new RegExp(r.v, r.case ? 'i' : '');
            } catch (e) {
                aviso('regex inválida: ' + r.v);
            }
        }
        return regra;
    });
}

module.exports = {
    barramento,
    normalizar,
    ler,
    montar,
    interpretar,
    REGRAS_PADRAO,
    avaliar,
    compilarRegras
};
