const util = require('util');
const { barramento, ler, interpretar, avaliar, compilarRegras } = require('./comum');
const { interpretar: interpretarHora, proximoInstante, instanteAnterior } = require('./hora');
const ping = require('./ping');

const REGRAS_PADRAO = [{ t: 'ignorar', alvo: '*', chave: '', espera: '', a: 'orig' }];
const OPERADORES_DEGRAU = ['eq', 'neq', 'lt', 'lte', 'gt', 'gte', 'btwn', 'cont', 'regex', 'true', 'false', 'empty', 'nempty'];

module.exports = function (RED) {
    function diasAgenda(c) {
        if (!Array.isArray(c.agendaDias)) return null;
        const dias = Array.from(new Set(c.agendaDias.map(Number).filter((d) => Number.isInteger(d) && d >= 0 && d <= 6)));
        return dias.length && dias.length < 7 ? dias : null;
    }

    function especAgenda(c) {
        const kind = String(c.agenda || '');
        if (kind === 'fixo') return interpretarHora(c.agendaHora);
        if (kind !== 'nascer' && kind !== 'por') return null;
        return interpretarHora(kind);
    }

    function EstadoSensor(config) {
        RED.nodes.createNode(this, config);
        const node = this;
        const global = node.context().global;

        const campos = (Array.isArray(config.campos) ? config.campos : [])
            .map((c, i) => {
                const nome = String(c.global || '').trim();
                return {
                    campo: String(c.campo || '').trim(),
                    propriedade: String(c.propriedade || '').trim(),
                    tipo: c.tipo === 'flow' || c.tipo === 'global' ? c.tipo : 'msg',
                    global: nome,
                    numero: i + 1,
                    key: nome || String(c.id || '').trim() || '#' + (i + 1),
                    mqtt: c.mqtt === undefined ? undefined : c.mqtt === true || c.mqtt === 'true',
                    broker: String(c.broker || '').trim(),
                    topico: String(c.topico || '').trim(),
                    qos: Number(c.qos) || 0,
                    intervalo: Math.max(0, Math.floor(Number(c.intervalo) || 0)),
                    agenda: especAgenda(c),
                    agendaDias: diasAgenda(c),
                    ping: c.ping === true || c.ping === 'true',
                    endereco: String(c.endereco || '').trim(),
                    porta: ping.lerPorta(c.porta),
                    pingIntervalo: Math.max(5, Math.floor(Number(c.pingIntervalo) || 10)),
                    ultima: null
                };
            });
        const comGlobal = campos.filter((c) => c.global);

        const verdadeiro = (v) => v === true || v === 'true';
        const tipo = ['status', 'leitura', 'comando'].includes(config.tipo) ? config.tipo : '';
        campos.forEach((c) => {
            if (!c.ping) return;
            if (tipo !== 'status') {
                c.ping = false;
                return;
            }
            c.tipo = 'msg';
            c.mqtt = false;
            c.intervalo = 0;
            c.agenda = null;
        });
        if (tipo === 'leitura') {
            campos.forEach((c) => {
                if (c.mqtt) c.mqtt = false;
            });
        }
        const statusPorEntrada = tipo !== '' && campos.some((c) => c.mqtt !== undefined);
        if (statusPorEntrada) {
            campos.forEach((c) => {
                if (c.mqtt) c.tipo = 'msg';
            });
        }
        const usaMqtt = tipo === 'comando' || statusPorEntrada ? false : config.mqtt === undefined ? !!config.broker : verdadeiro(config.mqtt);
        const usaMsg =
            tipo === 'comando'
                ? true
                : tipo === 'status'
                  ? false
                  : statusPorEntrada
                    ? true
                    : config.msg === undefined
                      ? true
                      : verdadeiro(config.msg);

        if (!campos.length) {
            node.status({ fill: 'red', shape: 'ring', text: 'sem entradas' });
            return;
        }

        const lista = Array.isArray(config.rules) && config.rules.length ? config.rules : REGRAS_PADRAO;
        const local = { lat: config.latitude, lon: config.longitude };
        const regras = compilarRegras(lista, (m) => node.warn(m), local);
        const esperas = lista.map((r) => (Number(r.espera) > 0 ? Number(r.espera) : 0));
        const destinos = lista.map((r) => {
            const prop = String(r.propsaida || '').trim();
            if (prop) return { tipo: r.tiposaida === 'flow' || r.tiposaida === 'global' ? r.tiposaida : 'msg', prop };
            const chave = String(r.chave || '').trim();
            return chave ? { tipo: 'chave', prop: chave } : { tipo: 'msg', prop: 'payload' };
        });
        const nomesGlobais = [];
        comGlobal.forEach((c) => {
            if (!nomesGlobais.includes(c.global)) nomesGlobais.push(c.global);
        });
        destinos.forEach((d) => {
            if (d.tipo === 'global' && !nomesGlobais.includes(d.prop)) nomesGlobais.push(d.prop);
        });
        const pendentes = new Map();
        const ultimoEnviado = new Map();
        let publicador = null;
        const comandoPorRegra = tipo !== '' && lista.some((r) => r.mqtt !== undefined);
        const conexoes = new Map();
        const porta = [];
        let totalPortas = 0;
        lista.forEach((r, i) => {
            porta[i] = comandoPorRegra && tipo !== 'comando' && r.msg === false ? -1 : totalPortas++;
        });

        function curinga(c, base) {
            return c.mqtt && /[+#]/.test(c.topico) ? String(base.topic) : '';
        }

        function chaveMemoria(i, c, sufixo) {
            return i + '|' + c.key + '|' + sufixo;
        }

        function destinosComuns(i) {
            const d = destinos[i];
            const r = lista[i];
            const comuns = [];
            if (d.tipo !== 'msg') comuns.push(d.tipo + ':' + d.prop);
            if (comandoPorRegra) {
                if (r.mqtt === true || r.mqtt === 'true') comuns.push('mqtt:' + r.broker + '|' + String(r.topico || '').trim());
            } else if (config.pubMqtt === true || config.pubMqtt === 'true') {
                comuns.push('mqtt:publicar');
            }
            return comuns;
        }

        function lembrar(i, c, sufixo, enviado) {
            ultimoEnviado.set(chaveMemoria(i, c, sufixo), { i, c, sufixo, enviado });
        }

        function esquecer(i, c, sufixo, valor, enviado) {
            const comuns = destinosComuns(i);
            ultimoEnviado.forEach((m, chave) => {
                if (m.i === i && m.c === c && m.sufixo === sufixo) return;
                const deixouDeValer = m.c === c && m.sufixo === sufixo && !passa(m.i, valor);
                const mesmoDestino = !util.isDeepStrictEqual(m.enviado, enviado) && destinosComuns(m.i).some((d) => comuns.includes(d));
                if (deixouDeValer || mesmoDestino) ultimoEnviado.delete(chave);
            });
        }

        function texto(valor) {
            return typeof valor === 'object' && valor !== null ? JSON.stringify(valor) : String(valor);
        }

        let exibido = null;
        let ciclos = 0;

        function resumo() {
            const partes = nomesGlobais.map((nome) => {
                const v = global.get(nome);
                return v === undefined ? null : nomesGlobais.length > 1 ? nome + '=' + texto(v) : texto(v);
            });
            return partes.filter((p) => p !== null).join(' | ');
        }

        function mostrar() {
            exibido = resumo();
            if (!exibido && !pendentes.size) {
                node.status({});
                return;
            }
            node.status({
                fill: pendentes.size ? 'yellow' : nomesGlobais.length === 1 && global.get(nomesGlobais[0]) === 'ON' ? 'green' : 'grey',
                shape: pendentes.size ? 'ring' : 'dot',
                text: exibido || '...'
            });
        }

        const vigia = setInterval(() => {
            ciclos++;
            if (resumo() !== exibido || ciclos % 10 === 0) mostrar();
        }, 2000);

        function carga(regra, valor) {
            switch (regra.a) {
                case 'str':
                    return String(regra.e === undefined ? '' : regra.e);
                case 'num':
                    return Number(regra.e);
                case 'bool':
                    return String(regra.e === undefined ? '' : regra.e).trim().toLowerCase() === 'true';
                case 'json':
                    try {
                        return JSON.parse(regra.e);
                    } catch (e) {
                        return undefined;
                    }
                default:
                    return valor;
            }
        }

        const escadas = lista.map((r) =>
            (Array.isArray(r.escada) ? r.escada : []).map((d) => ({
                alvo: d.alvo,
                regra: OPERADORES_DEGRAU.includes(d.t) ? compilarRegras([d], (m) => node.warn(m), local)[0] : null
            }))
        );
        const alvosDeDegrau = new Set([].concat(...escadas.map((e) => e.map((d) => d.alvo))));
        const deVariavel = (c) => (c.tipo === 'global' || c.tipo === 'flow') && !!c.propriedade;
        let foto = new Map();
        let degrausVistos = null;

        function tirarFoto() {
            return new Map(campos.filter(deVariavel).map((c) => [c, lerEntrada(c, {}, undefined)]));
        }

        function degrauVale(d) {
            const c = campos.find((x) => x.key === d.alvo);
            if (!c || !d.regra || !deVariavel(c)) return false;
            const valor = foto.get(c);
            return valor !== undefined && valor !== null && avaliar(d.regra, valor);
        }

        function passa(i, valor) {
            return avaliar(regras[i], valor) && escadas[i].every(degrauVale);
        }

        function conferirDegraus(atual) {
            if (!degrausVistos) return;
            campos
                .filter((c) => deVariavel(c) && alvosDeDegrau.has(c.key))
                .forEach((c) => {
                    const valor = atual.get(c);
                    if (util.isDeepStrictEqual(degrausVistos.get(c.key), valor)) return;
                    degrausVistos.set(c.key, valor);
                    ultimoEnviado.forEach((m, chave) => {
                        if (escadas[m.i].some((d) => d.alvo === c.key)) ultimoEnviado.delete(chave);
                    });
                });
        }

        function montarMensagem(i, c, valor, base) {
            const d = destinos[i];
            const enviado = carga(lista[i], valor);
            if (enviado === undefined) return null;
            if (tipo === 'status' || c.global || c.intervalo > 0 || c.agenda) {
                const sufixo = curinga(c, base);
                const anterior = ultimoEnviado.get(chaveMemoria(i, c, sufixo));
                if (!verdadeiro(lista[i].sempre) && anterior && util.isDeepStrictEqual(anterior.enviado, enviado)) return null;
                esquecer(i, c, sufixo, valor, enviado);
                lembrar(i, c, sufixo, enviado);
            }
            const msg = RED.util.cloneMessage(base);
            msg.topic = d.tipo === 'chave' ? d.prop : c.global || (d.tipo === 'global' ? d.prop : 'entrada ' + c.numero);
            if (d.tipo === 'chave') {
                msg.payload = { [d.prop]: enviado };
            } else if (d.tipo === 'msg') {
                RED.util.setMessageProperty(msg, d.prop, enviado, true);
            } else {
                node.context()[d.tipo].set(d.prop, enviado);
                msg.payload = enviado;
                const caminho = String(lista[i].propmsg || '').trim();
                if (caminho.indexOf('payload.') === 0) msg.payload = {};
                if (caminho && caminho !== 'payload') RED.util.setMessageProperty(msg, caminho, enviado, true);
            }
            return msg;
        }

        function publicar(msg, i) {
            const porRegra = comandoPorRegra && lista[i] && lista[i].mqtt !== undefined;
            if (porRegra && !verdadeiro(lista[i].mqtt)) return;
            const conexao = porRegra ? conexoes.get(lista[i].broker) : publicador;
            if (!conexao) {
                if (porRegra) node.status({ fill: 'red', shape: 'ring', text: 'broker de saída não encontrado' });
                return;
            }
            const topico = String((porRegra ? lista[i].topico : config.pubTopico) || '').trim();
            if (!topico) {
                node.status({ fill: 'yellow', shape: 'ring', text: 'sem tópico de saída' });
                return;
            }
            const p = msg.payload;
            conexao.publish(
                {
                    topic: topico,
                    payload: typeof p === 'string' ? p : typeof p === 'object' && p !== null ? JSON.stringify(p) : String(p),
                    qos: Number(porRegra ? lista[i].qos : config.pubQos) || 0,
                    retain: verdadeiro(porRegra ? lista[i].retain : config.pubRetain)
                },
                (erro) => {
                    if (erro) node.error(erro, msg);
                }
            );
        }

        function enviarLote(itens) {
            if (!itens.length) return;
            itens.forEach((item) => publicar(item.msg, item.i));
            if (tipo === 'comando') return;
            const saidas = new Array(totalPortas).fill(null);
            itens.forEach((item) => {
                if (porta[item.i] < 0) return;
                saidas[porta[item.i]] = (saidas[porta[item.i]] || []).concat([item.msg]);
            });
            if (saidas.every((s) => s === null)) return;
            node.send(saidas.map((s) => (s && s.length === 1 ? s[0] : s)));
        }

        function guardar(c, valor) {
            if (!c.global) return;
            if (util.isDeepStrictEqual(global.get(c.global), valor)) return;
            global.set(c.global, valor);
            barramento.emit(c.global, valor);
        }

        function valorNoFim(i, c, valor) {
            foto = tirarFoto();
            conferirDegraus(foto);
            if (!deVariavel(c)) return passa(i, valor) || !escadas[i].length ? valor : undefined;
            const atual = lerEntrada(c, {}, undefined);
            if (atual === undefined || atual === null) return undefined;
            if (!escadas[i].length && util.isDeepStrictEqual(atual, valor)) return valor;
            return passa(i, atual) ? atual : undefined;
        }

        function esperar(i, c, valor, base) {
            const chaveTimer = chaveMemoria(i, c, curinga(c, base));
            const existente = pendentes.get(chaveTimer);
            if (existente) {
                existente.valor = valor;
                return;
            }
            const timer = setTimeout(() => {
                const pendente = pendentes.get(chaveTimer);
                pendentes.delete(chaveTimer);
                const final = valorNoFim(i, c, pendente.valor);
                const msg = final === undefined ? null : montarMensagem(i, c, final, base);
                if (msg) enviarLote([{ i, msg }]);
                mostrar();
            }, esperas[i] * 1000);
            pendentes.set(chaveTimer, { timer, valor });
        }

        function cancelar(i, c, base) {
            const chaveTimer = chaveMemoria(i, c, curinga(c, base));
            const existente = pendentes.get(chaveTimer);
            if (!existente) return;
            clearTimeout(existente.timer);
            pendentes.delete(chaveTimer);
        }

        function avaliarRegras(c, valor, base, lote) {
            for (let i = 0; i < regras.length; i++) {
                const alvo = lista[i].alvo || '*';
                if (alvo !== '*' && alvo !== c.key) continue;
                const ok = passa(i, valor);
                if (esperas[i] > 0) {
                    if (ok) esperar(i, c, valor, base);
                    else cancelar(i, c, base);
                } else if (ok) {
                    const msg = montarMensagem(i, c, valor, base);
                    if (msg) lote.push({ i, msg });
                }
            }
        }

        function lerEntrada(c, msg, dados) {
            if (!c.propriedade) return ler(dados, c.campo);
            try {
                if (c.tipo === 'flow') return node.context().flow.get(c.propriedade);
                if (c.tipo === 'global') return global.get(c.propriedade);
                return RED.util.getMessageProperty(Object.assign({}, msg, { payload: dados }), c.propriedade);
            } catch (e) {
                return undefined;
            }
        }

        function tratar(msg, send, done, so) {
            const base = Object.assign({}, msg);
            delete base.payload;
            const dados = interpretar(msg.payload);
            const lote = [];
            foto = tirarFoto();
            conferirDegraus(foto);
            campos.forEach((c) => {
                if (so && !so.includes(c)) return;
                const valor = deVariavel(c) ? foto.get(c) : lerEntrada(c, msg, dados);
                if (valor === undefined || valor === null) return;
                guardar(c, valor);
                avaliarRegras(c, valor, base, lote);
            });
            mostrar();
            enviarLote(lote);
            done();
        }

        function semear() {
            destinos.forEach((d, i) => {
                if (d.tipo !== 'global') return;
                const atual = global.get(d.prop);
                if (atual === undefined || atual === null) return;
                const alvo = lista[i].alvo || '*';
                campos.filter((c) => alvo === '*' || alvo === c.key).forEach((c) => lembrar(i, c, '', atual));
            });
            comGlobal.forEach((c) => {
                const anterior = global.get(c.global);
                if (anterior === undefined || anterior === null) return;
                for (let i = 0; i < regras.length; i++) {
                    const alvo = lista[i].alvo || '*';
                    if (alvo !== '*' && alvo !== c.key) continue;
                    if (!avaliar(regras[i], anterior)) continue;
                    lembrar(i, c, '', carga(lista[i], anterior));
                }
            });
        }

        if (comandoPorRegra) {
            lista.forEach((r) => {
                if (!verdadeiro(r.mqtt) || !r.broker || conexoes.has(r.broker)) return;
                const b = RED.nodes.getNode(r.broker);
                if (!b) return;
                conexoes.set(r.broker, b);
                b.register(node);
            });
            node.on('close', (removido, pronto) => {
                let falta = conexoes.size;
                if (!falta) {
                    pronto();
                    return;
                }
                conexoes.forEach((b) =>
                    b.deregister(
                        node,
                        () => {
                            falta--;
                            if (falta === 0) pronto();
                        },
                        removido
                    )
                );
            });
        } else if (tipo !== 'status' && verdadeiro(config.pubMqtt)) {
            publicador = config.pubBroker ? RED.nodes.getNode(config.pubBroker) : null;
            if (!publicador) {
                node.status({ fill: 'red', shape: 'ring', text: 'broker de saída não encontrado' });
            } else {
                publicador.register(node);
                node.on('close', (removido, pronto) => {
                    publicador.deregister(node, pronto, removido);
                });
            }
        }

        semear();
        mostrar();
        if (alvosDeDegrau.size) {
            foto = tirarFoto();
            degrausVistos = new Map(campos.filter((c) => deVariavel(c) && alvosDeDegrau.has(c.key)).map((c) => [c.key, foto.get(c)]));
            const olhoDegraus = setInterval(() => conferirDegraus(tirarFoto()), 1000);
            node.on('close', () => clearInterval(olhoDegraus));
        }

        if (usaMsg) node.on('input', (msg, send, done) => tratar(msg, send, done, campos.filter((c) => !c.mqtt)));

        if (statusPorEntrada) {
            const assinaturas = [];
            const brokers = new Map();
            campos.forEach((c, i) => {
                if (!c.mqtt) return;
                const b = c.broker ? RED.nodes.getNode(c.broker) : null;
                if (!b) {
                    node.status({ fill: 'red', shape: 'ring', text: 'broker não encontrado' });
                    return;
                }
                if (!c.topico) {
                    node.status({ fill: 'red', shape: 'ring', text: 'sem tópico' });
                    return;
                }
                if (!brokers.has(c.broker)) {
                    brokers.set(c.broker, b);
                    b.register(node);
                }
                const ref = node.id + '|' + i;
                b.subscribe(
                    c.topico,
                    { qos: c.qos },
                    (recebido, payload) => {
                        c.ultima = { topic: recebido, payload };
                        tratar({ topic: recebido, payload, _msgid: RED.util.generateId() }, () => {}, () => {}, [c]);
                    },
                    ref
                );
                assinaturas.push({ b, topico: c.topico, ref });
            });
            node.on('close', (removido, pronto) => {
                assinaturas.forEach((a) => a.b.unsubscribe(a.topico, a.ref, removido));
                let falta = brokers.size;
                if (!falta) {
                    pronto();
                    return;
                }
                brokers.forEach((b) =>
                    b.deregister(
                        node,
                        () => {
                            falta--;
                            if (falta === 0) pronto();
                        },
                        removido
                    )
                );
            });
        }

        if (tipo === 'status') {
            const observadas = campos.filter((c) => (c.tipo === 'global' || c.tipo === 'flow') && c.propriedade && !(c.intervalo > 0) && !c.agenda);
            if (observadas.length) {
                const vistos = new Map(observadas.map((c) => [c, lerEntrada(c, {}, undefined)]));
                const olho = setInterval(() => {
                    const mudaram = observadas.filter((c) => {
                        const v = lerEntrada(c, {}, undefined);
                        if (util.isDeepStrictEqual(vistos.get(c), v)) return false;
                        vistos.set(c, v);
                        return true;
                    });
                    if (mudaram.length) tratar({ topic: 'global', _msgid: RED.util.generateId() }, () => {}, () => {}, mudaram);
                }, 1000);
                node.on('close', () => clearInterval(olho));
            }
        }

        if (tipo === 'status') {
            const relogios = [];
            const disparar = (c) => {
                if (c.mqtt) {
                    if (!c.ultima) return;
                    tratar({ topic: c.ultima.topic, payload: c.ultima.payload, _msgid: RED.util.generateId() }, () => {}, () => {}, [c]);
                    return;
                }
                const sinal = { topic: 'agenda', _msgid: RED.util.generateId() };
                if (c.tipo === 'msg' && c.propriedade) RED.util.setMessageProperty(sinal, c.propriedade, Date.now(), true);
                tratar(sinal, () => {}, () => {}, [c]);
            };
            const lat = config.latitude !== undefined && String(config.latitude).trim() !== '' ? Number(config.latitude) : null;
            const lon = config.longitude !== undefined && String(config.longitude).trim() !== '' ? Number(config.longitude) : null;
            const agendados = new Set();
            function armar(c) {
                const alvo = proximoInstante(c.agenda, new Date(), lat, lon, c.agendaDias);
                if (alvo === null) {
                    node.warn('agenda da entrada ' + c.numero + ': sem horário hoje');
                    return;
                }
                const t = setTimeout(() => {
                    agendados.delete(t);
                    disparar(c);
                    armar(c);
                }, Math.max(1000, alvo - Date.now()));
                agendados.add(t);
            }
            const agendadas = campos.filter((c) => c.agenda);
            let vencedora = null;
            let vencedoraEm = -Infinity;
            agendadas.forEach((c) => {
                const quando = instanteAnterior(c.agenda, new Date(), lat, lon, c.agendaDias);
                if (quando !== null && quando > vencedoraEm) {
                    vencedora = c;
                    vencedoraEm = quando;
                }
            });
            campos
                .filter((c) => c.intervalo > 0 || c.agenda)
                .forEach((c) => {
                    if (c.intervalo > 0) relogios.push(setInterval(() => disparar(c), c.intervalo * 1000));
                    if (c.agenda) armar(c);
                    if (c.intervalo > 0 || !c.agenda || agendadas.length === 1 || c === vencedora) setTimeout(() => disparar(c), 0);
                });
            node.on('close', () => {
                relogios.forEach((r) => clearInterval(r));
                agendados.forEach((t) => clearTimeout(t));
            });
        }

        if (tipo === 'status') {
            campos
                .filter((c) => c.ping)
                .forEach((c) => {
                    if (!ping.enderecoValido(c.endereco)) {
                        node.status({ fill: 'red', shape: 'ring', text: 'ping: endereço inválido' });
                        return;
                    }
                    if (c.porta === null) {
                        node.status({ fill: 'red', shape: 'ring', text: 'ping: porta inválida' });
                        return;
                    }
                    let medindo = false;
                    let fechado = false;
                    let processo = null;
                    const verificar = () => {
                        if (medindo) return;
                        medindo = true;
                        processo = ping.medir(c.endereco, (resultado) => {
                            medindo = false;
                            if (fechado) return;
                            if (resultado.falha) {
                                node.status({ fill: 'red', shape: 'ring', text: resultado.falha });
                                return;
                            }
                            const sinal = { topic: c.porta ? c.endereco + ':' + c.porta : c.endereco, _msgid: RED.util.generateId() };
                            RED.util.setMessageProperty(sinal, c.propriedade || 'payload', resultado.ms, true);
                            tratar(sinal, () => {}, () => {}, [c]);
                        }, c.porta);
                    };
                    const relogio = setInterval(verificar, c.pingIntervalo * 1000);
                    const partida = setTimeout(verificar, 0);
                    node.on('close', () => {
                        fechado = true;
                        clearInterval(relogio);
                        clearTimeout(partida);
                        if (medindo && processo && processo.kill) processo.kill();
                    });
                });
        }

        node.on('close', () => {
            clearInterval(vigia);
            pendentes.forEach((p) => clearTimeout(p.timer));
            pendentes.clear();
        });

        if (usaMqtt) {
            const conexao = config.broker ? RED.nodes.getNode(config.broker) : null;
            const topico = String(config.topico || '').trim();
            if (!conexao) {
                node.status({ fill: 'red', shape: 'ring', text: 'broker não encontrado' });
                return;
            }
            if (!topico) {
                node.status({ fill: 'red', shape: 'ring', text: 'sem tópico' });
                return;
            }
            conexao.register(node);
            conexao.subscribe(
                topico,
                { qos: Number(config.qos) || 0 },
                (recebido, payload) => {
                    tratar({ topic: recebido, payload, _msgid: RED.util.generateId() }, () => {}, () => {});
                },
                node.id
            );
            node.on('close', (removido, pronto) => {
                conexao.unsubscribe(topico, node.id, removido);
                conexao.deregister(node, pronto, removido);
            });
        }
    }
    RED.nodes.registerType('neway-auto', EstadoSensor);
};
